package com.Answer.QustionAnswer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QustionAnswerApplicationTests {

	@Test
	void contextLoads() {
	}

}
